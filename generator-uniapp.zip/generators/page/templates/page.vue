<template>
  <view class="<%= className %>"></view>
</template>

<script>
export default {
  name: '<%= componentName %>',
  data () {
    return {}
  },
  onLoad () {

  },
  methods: {}
}
</script>

<style lang="scss" scoped>
  .<%= className %> {

  }
</style>
