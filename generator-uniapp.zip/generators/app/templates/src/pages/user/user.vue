<template>
  <view>User</view>
</template>

<script>
export default {
  name: 'User'
}
</script>

<style scoped>

</style>
