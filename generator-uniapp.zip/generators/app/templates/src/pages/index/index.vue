<template>
  <view class="index">
    Index
  </view>
</template>

<script>
export default {
  name: 'Index'
}
</script>

<style lang="scss" scoped>

</style>
