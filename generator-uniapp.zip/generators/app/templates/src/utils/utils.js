export function sayHello () {
  return 'Hello <%= name %>'
}
