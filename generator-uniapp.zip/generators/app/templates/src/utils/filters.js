import Vue from 'vue'

Vue.filter('custom-filter', function (value) {
  return value
})
