const <%= storeName %> = {
  state: {

  },
  mutations: {

  },
  actions: {

  }
}

export default <%= storeName %>
